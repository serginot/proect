import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class quitterPage implements ActionListener{
		
		public void actionPerformed (ActionEvent event)
	    {				
			System.exit(0);					
		}
};
		
	

