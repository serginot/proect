import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.border.LineBorder;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;

import javax.swing.JColorChooser;
import javax.swing.JMenuBar;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JMenu;

public class Fenetre1 extends JFrame {

	
	// Declarations des variables
	private static final long serialVersionUID = -788267919462268937L;
	private JPanel contentPane;
	public Point origin;
    public Point end;
	public ArrayList<MyPaintedLabel> mesFormes = new ArrayList<MyPaintedLabel>();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fenetre1 frame1 = new Fenetre1();
					// Titre de la Fen�tre
					frame1.setTitle("Paint");
					frame1.setVisible(true);
					 
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
		

	/**
	 * Create the frame.
	 */
	public Fenetre1() {
		// Ne peut pas �tre redimensionn�
		this.setResizable(false);
		// Parametrage de la Jframe
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 720, 574);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		final MyPaintedPanel dessin = new MyPaintedPanel(new BorderLayout());
		this.contentPane.add(dessin);
		
		final JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_1.setBackground(Color.RED);
		panel_1.setBounds(385, 46, 309, 141);
		contentPane.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(386, 214, 309, 294);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 715, 25);
		contentPane.add(menuBar);
		
		
		//Cr�er le bouton
        final javax.swing.JButton button = new JButton();
        button.setBounds(85, 55, 151, 23);
        button.setText("Choisir une couleur");
                
        //Ajouter un evenement sur le click de la souris
        MouseAdapter actionListener = new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Color background = JColorChooser.showDialog(null,
                        "JColorChooser Sample", null);
                if (background != null) {
                	panel_1.setBackground(background);
                	dessin.setCouleur(background);
                }
            }
        };
        button.addMouseListener(actionListener);
        panel_1.setLayout(null);
                
        panel_1.add(button);
        panel_1.setSize(310, 140);
        panel_1.setVisible(true);
        
	    // On cr�� le listener pour quitter 
		//quitterPage listenerQuitter = new quitterPage();
	 
	    // On �coute des �v�nements de type "action" sur le bouton quitter du menu
		//boutonQuitter.addActionListener(listenerQuitter);
	}
}


