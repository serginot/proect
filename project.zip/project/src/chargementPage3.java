import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class chargementPage3 implements ActionListener{
		
		public void actionPerformed (ActionEvent event)
	    {				

			Fenetre3 frame3= new Fenetre3();
			frame3.setTitle("Paint");
			frame3.setVisible(true);
			
		}
};
		
	

