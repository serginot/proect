import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.border.LineBorder;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JMenuBar;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JMenu;


public class Fenetre2 extends JFrame {

	
	// Declarations des variables
	private static final long serialVersionUID = 1040145426965929613L;
	private JPanel contentPane;
	public Point origin;
    public Point end;
	public ArrayList<MyPaintedLabel> mesFormes = new ArrayList<MyPaintedLabel>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fenetre2 frame = new Fenetre2();
					frame.setTitle("Paint");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Fenetre2() {		
		// Ne peut pas �tre redimensionn�
		this.setResizable(false);
		// Parametrage de la Jframe
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 720, 574);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
				
		final MyPaintedPanel dessin = new MyPaintedPanel(new BorderLayout());
		this.contentPane.add(dessin);
		
		final JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_1.setBackground(Color.RED);
		panel_1.setBounds(385, 46, 309, 141);
		contentPane.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(385, 379, 309, 129);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
        
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 715, 25);
		contentPane.add(menuBar);
		
		
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_3.setBackground(Color.GREEN);
		panel_3.setBounds(385, 207, 309, 141);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblModeAffichage = new JLabel("Mode affichage");
		lblModeAffichage.setBounds(75, 11, 160, 22);
		lblModeAffichage.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_3.add(lblModeAffichage);
		
		JCheckBox chckbxRemplie = new JCheckBox("Remplie");
		chckbxRemplie.setBounds(173, 63, 109, 23);
		
		JCheckBox chckbxFilDeFer = new JCheckBox("Fil de fer", true);
		chckbxFilDeFer.setBounds(30, 63, 109, 23);
				
		ButtonGroup groupeBox = new ButtonGroup();
		groupeBox.add(chckbxRemplie);
		groupeBox.add(chckbxFilDeFer);
		panel_3.add(chckbxRemplie);
		panel_3.add(chckbxFilDeFer);
		
		chckbxFilDeFer.addActionListener(new java.awt.event.ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Stub de la m�thode g�n�r� automatiquement
				MyPaintedPanel.setRempli(false);
			}
		});
		chckbxRemplie.addActionListener(new java.awt.event.ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Stub de la m�thode g�n�r� automatiquement
				MyPaintedPanel.setRempli(true);
			}
		});
		
		//Cr�er le bouton
        final javax.swing.JButton button = new JButton();
        button.setBounds(76, 54, 172, 23);
        button.setText("Choisir une couleur");
        
        //Ajouter un evenement sur le click de la souris
        MouseAdapter actionListener = new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Color background = JColorChooser.showDialog(null,
                        "JColorChooser Sample", null);
                if (background != null) {
                	panel_1.setBackground(background);
                	dessin.setCouleur(background);
                }
            }
        };
        button.addMouseListener(actionListener);
        panel_1.setLayout(null);
                
        panel_1.add(button);
        panel_1.setSize(310, 140);
        panel_1.setVisible(true);
	}
	
}
